﻿using Microsoft.Maui.Controls.Hosting;
using Microsoft.Maui.Hosting;
using HairSalonApp.Services;
using HairSalonApp.ViewModels;
using Microsoft.Extensions.Logging;

namespace HairSalonApp;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                fonts.AddFont("GreatVibes-Regular.ttf", "GreatVibes");
            });

#if DEBUG
        builder.Logging.AddDebug();
#endif

        builder.Services.AddSingleton<DatabaseService>();
        builder.Services.AddSingleton<MainViewModel>();
        builder.Services.AddTransient<AppointmentViewModel>();

        return builder.Build();
    }
}