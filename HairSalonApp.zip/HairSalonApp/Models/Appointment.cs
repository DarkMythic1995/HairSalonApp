﻿using SQLite;
using System;

namespace HairSalonApp.Models;

public class Appointment
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
    public string CustomerName { get; set; }
    public DateTime AppointmentDate { get; set; }
    public string AppointmentTime { get; set; } // e.g., "09:00 AM"
    public string Service { get; set; }
    public string Stylist { get; set; }
    public string ContactInfo { get; set; } // Phone or email
    public string ClientStatus { get; set; } // New or Returning
    public DateTime CreatedAt { get; set; }

    public Appointment() { }

    public Appointment(string customerName, DateTime appointmentDate, string appointmentTime, string service, string stylist, string contactInfo, string clientStatus)
    {
        CustomerName = customerName;
        AppointmentDate = appointmentDate;
        AppointmentTime = appointmentTime;
        Service = service;
        Stylist = stylist;
        ContactInfo = contactInfo;
        ClientStatus = clientStatus;
        CreatedAt = DateTime.Now;
    }
}