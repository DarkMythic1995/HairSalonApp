﻿using System;

namespace HairSalonApp.Models;

public class Service
{
    public string Name { get; set; }
    public int DurationMinutes { get; set; }
    public decimal Price { get; set; }
    public string PriceNote { get; set; } // e.g., "Starting at" for Color

    public Service(string name, int durationMinutes, decimal price, string priceNote = null)
    {
        Name = name;
        DurationMinutes = durationMinutes;
        Price = price;
        PriceNote = priceNote;
    }

    public override string ToString() => Name; // For Picker display
}