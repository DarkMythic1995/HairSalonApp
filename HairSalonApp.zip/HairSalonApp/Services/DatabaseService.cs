﻿using HairSalonApp.Models;
using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace HairSalonApp.Services;

public class DatabaseService
{
    private readonly SQLiteAsyncConnection _database;

    public DatabaseService()
    {
        var dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HairSalonApp.db3");
        _database = new SQLiteAsyncConnection(dbPath);
        _database.CreateTableAsync<Appointment>().Wait();
    }

    public Task<List<Appointment>> GetAppointmentsAsync()
    {
        return _database.Table<Appointment>().ToListAsync();
    }

    public Task SaveAppointmentAsync(Appointment appointment)
    {
        return _database.InsertAsync(appointment);
    }
}