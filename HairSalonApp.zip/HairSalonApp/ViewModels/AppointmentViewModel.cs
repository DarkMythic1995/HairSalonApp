﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using HairSalonApp.Models;
using HairSalonApp.Services;
using System;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HairSalonApp.ViewModels;

public partial class AppointmentViewModel : ObservableObject
{
    private readonly HttpClient _httpClient;
    private readonly DatabaseService _databaseService;

    [ObservableProperty]
    private string _customerName;

    [ObservableProperty]
    private DateTime _appointmentDate = DateTime.Today;

    [ObservableProperty]
    private string _appointmentTime;

    [ObservableProperty]
    private Service _selectedService;

    [ObservableProperty]
    private string _selectedStylist;

    [ObservableProperty]
    private string _contactInfo;

    [ObservableProperty]
    private string _selectedClientStatus;

    [ObservableProperty]
    private ObservableCollection<Service> _availableServices = new ObservableCollection<Service>
    {
        new Service("Haircut", 30, 30.00m),
        new Service("Color", 90, 80.00m, "Starting at"),
        new Service("Styling", 45, 50.00m),
        new Service("Perm", 120, 100.00m)
    };

    [ObservableProperty]
    private ObservableCollection<string> _availableTimeSlots = new ObservableCollection<string>
    {
        "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
        "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM"
    };

    [ObservableProperty]
    private ObservableCollection<string> _availableStylists = new ObservableCollection<string>
    {
        "Jane",
        "Mike",
        "Sarah"
    };

    [ObservableProperty]
    private ObservableCollection<string> _clientStatuses = new ObservableCollection<string>
    {
        "New",
        "Returning"
    };

    [ObservableProperty]
    private string _successMessage;

    [ObservableProperty]
    private string _errorMessage;

    [ObservableProperty]
    private bool _isBusy;

    public ObservableCollection<Appointment> Appointments { get; } = new ObservableCollection<Appointment>();

    public DateTime TodayDate => DateTime.Today;

    public AppointmentViewModel(DatabaseService databaseService)
    {
        _databaseService = databaseService;
#if ANDROID
            _httpClient = new HttpClient { BaseAddress = new Uri("http://10.0.2.2:8080"), Timeout = TimeSpan.FromSeconds(10) };
#else
        _httpClient = new HttpClient { BaseAddress = new Uri("http://localhost:8080"), Timeout = TimeSpan.FromSeconds(10) };
#endif
    }

    [RelayCommand]
    public async Task TestApiConnection()
    {
        try
        {
            var response = await _httpClient.GetAsync("api/email/send");
            ErrorMessage = $"Test response: {response.StatusCode} ({(int)response.StatusCode})";
            await Shell.Current.DisplayAlert("Test", ErrorMessage, "OK");
        }
        catch (HttpRequestException ex)
        {
            ErrorMessage = $"Test connection error: {ex.Message} {(ex.InnerException != null ? $"Inner: {ex.InnerException.Message}" : "")}";
            await Shell.Current.DisplayAlert("Test", ErrorMessage, "OK");
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Test unexpected error: {ex.Message} {(ex.InnerException != null ? $"Inner: {ex.InnerException.Message}" : "")}";
            await Shell.Current.DisplayAlert("Test", ErrorMessage, "OK");
        }
    }

    [RelayCommand]
    public async Task SubmitAppointment()
    {
        IsBusy = true;
        SuccessMessage = string.Empty;
        ErrorMessage = string.Empty;

        // Validate inputs
        if (string.IsNullOrWhiteSpace(CustomerName))
        {
            ErrorMessage = "Customer name is required.";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        if (!Regex.IsMatch(CustomerName, @"^[a-zA-Z\s]+$"))
        {
            ErrorMessage = "Customer name must contain only letters and spaces.";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        if (SelectedService == null)
        {
            ErrorMessage = "Please select a service.";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        if (string.IsNullOrEmpty(AppointmentTime))
        {
            ErrorMessage = "Please select a time slot.";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        if (string.IsNullOrEmpty(SelectedStylist))
        {
            ErrorMessage = "Please select a stylist.";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        if (string.IsNullOrWhiteSpace(ContactInfo))
        {
            ErrorMessage = "Contact information is required.";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        if (!Regex.IsMatch(ContactInfo, @"^(\S+@\S+\.\S+|[0-9]{10})$"))
        {
            ErrorMessage = "Please enter a valid email or 10-digit phone number.";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        if (string.IsNullOrEmpty(SelectedClientStatus))
        {
            ErrorMessage = "Please select client status (New or Returning).";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        if (AppointmentDate < DateTime.Today)
        {
            ErrorMessage = "Appointment date cannot be in the past.";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            IsBusy = false;
            return;
        }

        try
        {
            var appointment = new
            {
                CustomerName,
                AppointmentDate,
                AppointmentTime,
                Service = SelectedService.Name,
                Stylist = SelectedStylist,
                ContactInfo,
                ClientStatus = SelectedClientStatus
            };

            var response = await _httpClient.PostAsJsonAsync("api/email/send", appointment);

            if (response.IsSuccessStatusCode)
            {
                var newAppointment = new Appointment(
                    CustomerName,
                    AppointmentDate,
                    AppointmentTime,
                    SelectedService.Name,
                    SelectedStylist,
                    ContactInfo,
                    SelectedClientStatus
                );
                await _databaseService.SaveAppointmentAsync(newAppointment);
                Appointments.Add(newAppointment);

                var priceDisplay = string.IsNullOrEmpty(SelectedService.PriceNote)
                    ? $"${SelectedService.Price:F2}"
                    : $"{SelectedService.PriceNote} ${SelectedService.Price:F2}";
                SuccessMessage = $"Thank you for submitting an appointment request, please wait for text message confirmation or phone call.\n" +
                                 $"Details: {CustomerName} on {AppointmentDate:MM/dd/yyyy} at {AppointmentTime} with {SelectedStylist} " +
                                 $"for {SelectedService.Name} ({SelectedClientStatus} client, {SelectedService.DurationMinutes} min, {priceDisplay}).";
                await Shell.Current.DisplayAlert("Success", SuccessMessage, "OK");

                CustomerName = string.Empty;
                AppointmentDate = DateTime.Today;
                AppointmentTime = null;
                SelectedService = null;
                SelectedStylist = null;
                ContactInfo = string.Empty;
                SelectedClientStatus = null;

                await Shell.Current.GoToAsync("///MainPage");
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                ErrorMessage = $"Failed to submit appointment: {errorContent}";
                await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
            }
        }
        catch (HttpRequestException ex)
        {
            ErrorMessage = $"Connection error: {ex.Message} {(ex.InnerException != null ? $"Inner: {ex.InnerException.Message}" : "")}";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
        }
        catch (Exception ex)
        {
            ErrorMessage = $"Unexpected error: {ex.Message} {(ex.InnerException != null ? $"Inner: {ex.InnerException.Message}" : "")}";
            await Shell.Current.DisplayAlert("Error", ErrorMessage, "OK");
        }
        finally
        {
            IsBusy = false;
        }
    }
}