﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Threading.Tasks;

namespace HairSalonApp.ViewModels;

public partial class MainViewModel : ObservableObject
{
    [RelayCommand]
    public async Task NavigateToAppointment()
    {
        await Shell.Current.GoToAsync("///AppointmentPage");
    }

    [RelayCommand]
    public async Task NavigateToService()
    {
        // Placeholder: Disabled in MainPage.xaml
    }

    [RelayCommand]
    public async Task NavigateToLoyalty()
    {
        // Placeholder: Disabled in MainPage.xaml
    }
}