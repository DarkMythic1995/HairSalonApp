using HairSalonApp.ViewModels;

namespace HairSalonApp.Views;

public partial class AppointmentPage : ContentPage
{
	public AppointmentPage(AppointmentViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
}